﻿using Npgsql;
using System;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class AddOwnerForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private int? ownerId = null; 

        public AddOwnerForm()
        {
            InitializeComponent();
        }


        public AddOwnerForm(int id)
        {
            InitializeComponent();
            ownerId = id;
            LoadOwnerData();
        }

        private void LoadOwnerData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"SELECT full_name, phone, email, address 
                                   FROM owners 
                                   WHERE owner_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", ownerId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                FIOTextBox.Text = reader.GetString(0);
                                PhoneTextBox.Text = reader.IsDBNull(1) ? "" : reader.GetString(1);
                                MailTextBox.Text = reader.IsDBNull(2) ? "" : reader.GetString(2);
                                AdressTextBox.Text = reader.IsDBNull(3) ? "" : reader.GetString(3);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string fullName = FIOTextBox.Text.Trim();
            string phone = PhoneTextBox.Text.Trim();
            string email = MailTextBox.Text.Trim();
            string address = AdressTextBox.Text.Trim();

            if (fullName == "")
            {
                MessageBox.Show("Введите ФИО владельца");
                return;
            }

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql;

                    if (ownerId == null)
                    {

                        sql = @"INSERT INTO owners (full_name, phone, email, address)
                                VALUES (@f, @p, @e, @a)";
                    }
                    else
                    {
         
                        sql = @"UPDATE owners
                                SET full_name=@f, phone=@p, email=@e, address=@a
                                WHERE owner_id=@id";
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("f", fullName);
                        cmd.Parameters.AddWithValue("p", (object)phone ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("e", (object)email ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("a", (object)address ?? DBNull.Value);

                        if (ownerId != null)
                            cmd.Parameters.AddWithValue("id", ownerId);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message);
            }
        }

        private void CanselButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
