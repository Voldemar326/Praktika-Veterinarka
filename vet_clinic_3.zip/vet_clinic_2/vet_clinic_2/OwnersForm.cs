﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class OwnersForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private string userRole;


        public OwnersForm(string role)
        {
            InitializeComponent();
            userRole = role;

            ApplyPermissions();   
            LoadOwners();         
        }

        private void LoadOwners()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            owner_id AS ""ID"",
                            full_name AS ""ФИО"",
                            phone AS ""Телефон"",
                            email AS ""Email"",
                            address AS ""Адрес""
                        FROM owners
                        ORDER BY owner_id;
                    ";

                    using (var adapter = new NpgsqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void AddOwner_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для добавления записей.");
                return;
            }

            AddOwnerForm form = new AddOwnerForm();
            if (form.ShowDialog() == DialogResult.OK)
                LoadOwners();
        }

        private void EditOwner_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для редактирования записей.");
                return;
            }

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите владельца для редактирования");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

            AddOwnerForm form = new AddOwnerForm(id);
            if (form.ShowDialog() == DialogResult.OK)
                LoadOwners();
        }

        private void DeleteOwner_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для удаления записей.");
                return;
            }

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите владельца для удаления");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

            DialogResult result = MessageBox.Show(
                "Вы действительно хотите удалить выбранного владельца?",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "DELETE FROM owners WHERE owner_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Владелец успешно удалён");
                LoadOwners();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message);
            }
        }


        private void ApplyPermissions()
        {
            if (userRole == "vet")
            {
                if (AddOwner != null)
                    AddOwner.Enabled = false;

                if (EditOwner != null)
                    EditOwner.Enabled = false;

                if (DeleteOwner != null)
                    DeleteOwner.Enabled = false;
            }
        }
    }
}
