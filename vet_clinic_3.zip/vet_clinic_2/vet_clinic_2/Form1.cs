﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class Form1 : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private string userRole;


        public Form1(string role)
        {
            InitializeComponent();
            userRole = role;

            InitSearchControls();
            ApplyPermissions();
            LoadData();
        }

        private void InitSearchControls()
        {
            comboBoxSearchBy.Items.Add("Кличка");
            comboBoxSearchBy.Items.Add("Владелец");
            comboBoxSearchBy.Items.Add("Порода");
            comboBoxSearchBy.Items.Add("Ветеринар");
            comboBoxSearchBy.SelectedIndex = 0;

            comboBoxSex.Items.Add("");
            comboBoxSex.Items.Add("Муж.");
            comboBoxSex.Items.Add("Жен.");
            comboBoxSex.SelectedIndex = 0;

            comboBoxSpecies.Items.Add("");
            comboBoxSpecies.Items.Add("Кот");
            comboBoxSpecies.Items.Add("Собака");
            comboBoxSpecies.Items.Add("Попугай");
            comboBoxSpecies.Items.Add("Хомяк");
            comboBoxSpecies.Items.Add("Кролик");
            comboBoxSpecies.SelectedIndex = 0;
        }

        private void ApplyPermissions()
        {
            if (userRole == "vet")
            {
                if (AdminEditButton != null)
                    AdminEditButton.Enabled = false;


                if (AddRecordButton != null)
                    AddRecordButton.Enabled = false;

                if (EditRecordButton != null)
                    EditRecordButton.Enabled = false;

                if (DeleteRecordButton != null)
                    DeleteRecordButton.Enabled = false;
            }

            if (userRole == "admin")
            {

            }
        }


        private void LoadData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            r.record_id AS ""ID записи"",
                            a.name AS ""Животное"",
                            o.full_name AS ""Владелец"",
                            v.full_name AS ""Ветеринар"",
                            r.record_date AS ""Дата приёма"",
                            r.type AS ""Тип"",
                            d.name AS ""Диагноз"",
                            r.description AS ""Описание"",
                            r.cost AS ""Стоимость""
                        FROM records r
                        LEFT JOIN animals a ON r.animal_id = a.animal_id
                        LEFT JOIN owners o ON a.owner_id = o.owner_id
                        LEFT JOIN vets v ON r.vet_id = v.vet_id
                        LEFT JOIN diseases d ON r.diagnosis_id = d.disease_id;
                    ";

                    using (var adapter = new NpgsqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }


        private void LoadDataWithFilters()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            r.record_id AS ""ID записи"",
                            a.name AS ""Животное"",
                            o.full_name AS ""Владелец"",
                            v.full_name AS ""Ветеринар"",
                            r.record_date AS ""Дата приёма"",
                            r.type AS ""Тип"",
                            d.name AS ""Диагноз"",
                            r.description AS ""Описание"",
                            r.cost AS ""Стоимость""
                        FROM records r
                        LEFT JOIN animals a ON r.animal_id = a.animal_id
                        LEFT JOIN owners o ON a.owner_id = o.owner_id
                        LEFT JOIN vets v ON r.vet_id = v.vet_id
                        LEFT JOIN diseases d ON r.diagnosis_id = d.disease_id
                        WHERE 1=1
                    ";

                    string search = textBoxSearch.Text.Trim();
                    string searchBy = comboBoxSearchBy.SelectedItem.ToString();

                    if (search != "")
                    {
                        if (comboBoxSearchBy.SelectedIndex == 0)
                            sql += " AND a.name ILIKE @search";

                        else if (comboBoxSearchBy.SelectedIndex == 1)
                            sql += " AND o.full_name ILIKE @search";

                        else if (comboBoxSearchBy.SelectedIndex == 2)
                            sql += " AND a.breed ILIKE @search";

                        else if (comboBoxSearchBy.SelectedIndex == 3)
                            sql += " AND v.full_name ILIKE @search";
                    }



                    if (comboBoxSex.SelectedIndex > 0)
                        sql += " AND a.sex = @sex";


                    if (comboBoxSpecies.SelectedIndex > 0)
                        sql += " AND a.species = @species";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        if (search != "")
                            cmd.Parameters.AddWithValue("search", "%" + search + "%");

                        if (comboBoxSex.SelectedIndex > 0)
                            cmd.Parameters.AddWithValue("sex", comboBoxSex.SelectedItem.ToString());

                        if (comboBoxSpecies.SelectedIndex > 0)
                            cmd.Parameters.AddWithValue("species", comboBoxSpecies.SelectedItem.ToString());

                        using (var adapter = new NpgsqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            dataGridView1.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка фильтрации: " + ex.Message);
            }
        }


        private void SearchButton_Click(object sender, EventArgs e)
        {
            LoadDataWithFilters();
        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            Application.OpenForms["AutorizationForm"].Show();
            this.Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                Application.OpenForms["AutorizationForm"].Show();
            }
        }

        private void AddRecordButton_Click(object sender, EventArgs e)
        {
            AddRecordForm form = new AddRecordForm();
            if (form.ShowDialog() == DialogResult.OK)
            {
                LoadData();
            }
        }

        private void EditRecordButton_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись для редактирования");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID записи"].Value);

            AddRecordForm form = new AddRecordForm(id);
            if (form.ShowDialog() == DialogResult.OK)
            {
                LoadData();
            }
        }

        private void DeleteRecordButton_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись для удаления");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID записи"].Value);

            DialogResult result = MessageBox.Show(
                "Вы действительно хотите удалить выбранную запись?",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "DELETE FROM records WHERE record_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Запись успешно удалена");
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message);
            }
        }

        private void DirectoryOpenButton_Click(object sender, EventArgs e)
        {
            DirectoryForm dir = new DirectoryForm(userRole);
            dir.ShowDialog();
        }



        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                ClearDetails();
                return;
            }

            var row = dataGridView1.SelectedRows[0];

            if (row.IsNewRow)
            {
                ClearDetails();
                return;
            }

            var cellValue = row.Cells["ID записи"].Value;

            if (cellValue == null || cellValue == DBNull.Value)
            {
                ClearDetails();
                return;
            }

            if (!int.TryParse(cellValue.ToString(), out int recordId))
            {
                ClearDetails();
                return;
            }

            LoadRecordDetails(recordId);
        }

        private void LoadRecordDetails(int recordId)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                SELECT 
                    a.name AS animal_name,
                    a.species AS animal_type,
                    a.sex AS animal_sex,
                    a.breed AS animal_breed,
                    a.birth_date AS birth_date,
                    a.notes AS animal_notes,

                    o.full_name AS owner_name,
                    o.phone AS owner_phone,
                    o.email AS owner_email,

                    v.full_name AS vet_name,
                    v.phone AS vet_phone,
                    v.email AS vet_email,

                    d.name AS disease_name,

                    r.type AS record_type,
                    r.record_date AS record_time

                FROM records r
                LEFT JOIN animals a ON r.animal_id = a.animal_id
                LEFT JOIN owners o ON a.owner_id = o.owner_id
                LEFT JOIN vets v ON r.vet_id = v.vet_id
                LEFT JOIN diseases d ON r.diagnosis_id = d.disease_id
                WHERE r.record_id = @id
            ";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", recordId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                AnimalName.Text = reader["animal_name"]?.ToString();
                                AnimalType.Text = reader["animal_type"]?.ToString();
                                AnimalSex.Text = reader["animal_sex"]?.ToString();
                                AnimalBreed.Text = reader["animal_breed"]?.ToString();


                                int birthOrd = reader.GetOrdinal("birth_date");
                                if (!reader.IsDBNull(birthOrd))
                                {
                                    var bd = reader.GetFieldValue<DateOnly>(birthOrd);
                                    BirthDate.Text = bd.ToString("dd.MM.yyyy");
                                }
                                else
                                {
                                    BirthDate.Text = "";
                                }

                                AnimalAnnotation.Text = reader["animal_notes"]?.ToString();

                                OwnerFullName.Text = reader["owner_name"]?.ToString();
                                OwnerPhone.Text = reader["owner_phone"]?.ToString();
                                OwnerMail.Text = reader["owner_email"]?.ToString();

                                VetFullName.Text = reader["vet_name"]?.ToString();
                                VetPhone.Text = reader["vet_phone"]?.ToString();
                                VetMail.Text = reader["vet_email"]?.ToString();

                                Disease.Text = reader["disease_name"]?.ToString();
                                RecordType.Text = reader["record_type"]?.ToString();

                                int timeOrd = reader.GetOrdinal("record_time");
                                if (!reader.IsDBNull(timeOrd))
                                {
                                    var dt = reader.GetDateTime(timeOrd);
                                    RecordTime.Text = dt.ToString("dd.MM.yyyy HH:mm");
                                }
                                else
                                {
                                    RecordTime.Text = "";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки подробной информации: " + ex.Message);
            }
        }

        private void ClearDetails()
        {
            AnimalName.Text = "";
            AnimalType.Text = "";
            AnimalSex.Text = "";
            AnimalBreed.Text = "";
            BirthDate.Text = "";
            OwnerFullName.Text = "";
            OwnerPhone.Text = "";
            OwnerMail.Text = "";
            VetFullName.Text = "";
            VetPhone.Text = "";
            VetMail.Text = "";
            Disease.Text = "";
            RecordType.Text = "";
            RecordTime.Text = "";
            AnimalAnnotation.Text = "";
        }

        private void AdminEditButton_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для управления пользователями.");
                return;
            }

            AdminEditForm form = new AdminEditForm();
            form.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AboutFormSpravka spravka = new AboutFormSpravka();
            spravka.ShowDialog();
        }
    }
}
