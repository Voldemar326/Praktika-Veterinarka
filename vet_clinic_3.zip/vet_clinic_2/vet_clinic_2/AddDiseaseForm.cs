﻿using Npgsql;
using System;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class AddDiseaseForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private int? diseaseId = null; 


        public AddDiseaseForm()
        {
            InitializeComponent();
        }


        public AddDiseaseForm(int id)
        {
            InitializeComponent();
            diseaseId = id;
            LoadDiseaseData();
        }

        private void LoadDiseaseData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"SELECT name, description, symptoms, treatment 
                                   FROM diseases 
                                   WHERE disease_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", diseaseId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                NameTextBox.Text = reader.GetString(0);
                                DescriptionTextBox.Text = reader.IsDBNull(1) ? "" : reader.GetString(1);
                                SimptomsTextBox.Text = reader.IsDBNull(2) ? "" : reader.GetString(2);
                                HealingTextBox.Text = reader.IsDBNull(3) ? "" : reader.GetString(3);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string name = NameTextBox.Text.Trim();
            string description = DescriptionTextBox.Text.Trim();
            string symptoms = SimptomsTextBox.Text.Trim();
            string treatment = HealingTextBox.Text.Trim();

            if (name == "")
            {
                MessageBox.Show("Введите название болезни");
                return;
            }

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql;

                    if (diseaseId == null)
                    {

                        sql = @"INSERT INTO diseases (name, description, symptoms, treatment)
                                VALUES (@n, @d, @s, @t)";
                    }
                    else
                    {

                        sql = @"UPDATE diseases
                                SET name=@n, description=@d, symptoms=@s, treatment=@t
                                WHERE disease_id=@id";
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("n", name);
                        cmd.Parameters.AddWithValue("d", (object)description ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("s", (object)symptoms ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("t", (object)treatment ?? DBNull.Value);

                        if (diseaseId != null)
                            cmd.Parameters.AddWithValue("id", diseaseId);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message);
            }
        }

        private void CanselButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
