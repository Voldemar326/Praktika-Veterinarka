﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class VetsForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private string userRole;


        public VetsForm(string role)
        {
            InitializeComponent();
            userRole = role;

            ApplyPermissions();   
            LoadVets();          
        }

        private void LoadVets()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            vet_id AS ""ID"",
                            full_name AS ""ФИО"",
                            specialization AS ""Специализация"",
                            experience_years AS ""Стаж (лет)"",
                            phone AS ""Телефон"",
                            email AS ""Email""
                        FROM vets
                        ORDER BY vet_id;
                    ";

                    using (var adapter = new NpgsqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void AddVets_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для добавления записей.");
                return;
            }

            AddVetForm form = new AddVetForm();
            if (form.ShowDialog() == DialogResult.OK)
                LoadVets();
        }

        private void EditVets_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для редактирования записей.");
                return;
            }

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите ветеринара для редактирования");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

            AddVetForm form = new AddVetForm(id);
            if (form.ShowDialog() == DialogResult.OK)
                LoadVets();
        }

        private void DeleteVets_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для удаления записей.");
                return;
            }

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите ветеринара для удаления");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

            DialogResult result = MessageBox.Show(
                "Вы действительно хотите удалить выбранного ветеринара?",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "DELETE FROM vets WHERE vet_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Ветеринар успешно удалён");
                LoadVets();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message);
            }
        }


        private void ApplyPermissions()
        {
            if (userRole == "vet")
            {
                if (AddVets != null)
                    AddVets.Enabled = false;

                if (EditVets != null)
                    EditVets.Enabled = false;

                if (DeleteVets != null)
                    DeleteVets.Enabled = false;
            }
        }
    }
}
