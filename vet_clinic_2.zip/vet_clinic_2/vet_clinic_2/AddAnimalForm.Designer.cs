﻿namespace vet_clinic_2
{
    partial class AddAnimalForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddAnimalForm));
            CanselButton = new Button();
            SaveButton = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            BreedTextBox = new TextBox();
            SpeciesTextBox = new TextBox();
            NameTextBox = new TextBox();
            comboBoxSex = new ComboBox();
            label4 = new Label();
            dateTimePickerBirth = new DateTimePicker();
            label5 = new Label();
            comboBoxOwner = new ComboBox();
            label6 = new Label();
            textBoxNotes = new TextBox();
            label7 = new Label();
            SuspendLayout();
            // 
            // CanselButton
            // 
            CanselButton.Location = new Point(354, 370);
            CanselButton.Name = "CanselButton";
            CanselButton.Size = new Size(103, 40);
            CanselButton.TabIndex = 19;
            CanselButton.Text = "Отмена";
            CanselButton.UseVisualStyleBackColor = true;
            CanselButton.Click += CanselButton_Click;
            // 
            // SaveButton
            // 
            SaveButton.Location = new Point(9, 370);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(111, 40);
            SaveButton.TabIndex = 18;
            SaveButton.Text = "Сохранить";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(27, 63);
            label3.Name = "label3";
            label3.Size = new Size(52, 15);
            label3.TabIndex = 16;
            label3.Text = "Порода:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(39, 39);
            label2.Name = "label2";
            label2.Size = new Size(30, 15);
            label2.TabIndex = 15;
            label2.Text = "Вид:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(29, 7);
            label1.Name = "label1";
            label1.Size = new Size(50, 15);
            label1.TabIndex = 14;
            label1.Text = "Кличка:";
            // 
            // BreedTextBox
            // 
            BreedTextBox.Location = new Point(87, 63);
            BreedTextBox.MaxLength = 40;
            BreedTextBox.Multiline = true;
            BreedTextBox.Name = "BreedTextBox";
            BreedTextBox.Size = new Size(370, 28);
            BreedTextBox.TabIndex = 12;
            // 
            // SpeciesTextBox
            // 
            SpeciesTextBox.Location = new Point(87, 36);
            SpeciesTextBox.MaxLength = 40;
            SpeciesTextBox.Multiline = true;
            SpeciesTextBox.Name = "SpeciesTextBox";
            SpeciesTextBox.Size = new Size(370, 23);
            SpeciesTextBox.TabIndex = 11;
            // 
            // NameTextBox
            // 
            NameTextBox.Location = new Point(85, 7);
            NameTextBox.MaxLength = 40;
            NameTextBox.Name = "NameTextBox";
            NameTextBox.Size = new Size(372, 23);
            NameTextBox.TabIndex = 10;
            // 
            // comboBoxSex
            // 
            comboBoxSex.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxSex.FormattingEnabled = true;
            comboBoxSex.Items.AddRange(new object[] { "Муж.", "Жен." });
            comboBoxSex.Location = new Point(87, 94);
            comboBoxSex.Name = "comboBoxSex";
            comboBoxSex.Size = new Size(370, 23);
            comboBoxSex.TabIndex = 20;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(39, 97);
            label4.Name = "label4";
            label4.Size = new Size(33, 15);
            label4.TabIndex = 21;
            label4.Text = "Пол:";
            // 
            // dateTimePickerBirth
            // 
            dateTimePickerBirth.Location = new Point(126, 123);
            dateTimePickerBirth.Name = "dateTimePickerBirth";
            dateTimePickerBirth.Size = new Size(331, 23);
            dateTimePickerBirth.TabIndex = 22;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(27, 129);
            label5.Name = "label5";
            label5.Size = new Size(93, 15);
            label5.TabIndex = 23;
            label5.Text = "Дата рождения:";
            // 
            // comboBoxOwner
            // 
            comboBoxOwner.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxOwner.FormattingEnabled = true;
            comboBoxOwner.Location = new Point(126, 152);
            comboBoxOwner.Name = "comboBoxOwner";
            comboBoxOwner.Size = new Size(331, 23);
            comboBoxOwner.TabIndex = 24;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(58, 152);
            label6.Name = "label6";
            label6.Size = new Size(62, 15);
            label6.TabIndex = 25;
            label6.Text = "Владелец:";
            // 
            // textBoxNotes
            // 
            textBoxNotes.Location = new Point(6, 201);
            textBoxNotes.MaxLength = 270;
            textBoxNotes.Multiline = true;
            textBoxNotes.Name = "textBoxNotes";
            textBoxNotes.Size = new Size(451, 163);
            textBoxNotes.TabIndex = 26;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 183);
            label7.Name = "label7";
            label7.Size = new Size(81, 15);
            label7.TabIndex = 27;
            label7.Text = "Примечания:";
            // 
            // AddAnimalForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(465, 419);
            Controls.Add(label7);
            Controls.Add(textBoxNotes);
            Controls.Add(label6);
            Controls.Add(comboBoxOwner);
            Controls.Add(label5);
            Controls.Add(dateTimePickerBirth);
            Controls.Add(label4);
            Controls.Add(comboBoxSex);
            Controls.Add(CanselButton);
            Controls.Add(SaveButton);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(BreedTextBox);
            Controls.Add(SpeciesTextBox);
            Controls.Add(NameTextBox);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddAnimalForm";
            Text = "Работа с животными";
            Load += AddAnimalForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CanselButton;
        private Button SaveButton;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox BreedTextBox;
        private TextBox SpeciesTextBox;
        private TextBox NameTextBox;
        private ComboBox comboBoxSex;
        private Label label4;
        private DateTimePicker dateTimePickerBirth;
        private Label label5;
        private ComboBox comboBoxOwner;
        private Label label6;
        private TextBox textBoxNotes;
        private Label label7;
    }
}