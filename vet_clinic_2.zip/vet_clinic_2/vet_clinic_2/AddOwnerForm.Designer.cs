﻿namespace vet_clinic_2
{
    partial class AddOwnerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddOwnerForm));
            CanselButton = new Button();
            SaveButton = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            AdressTextBox = new TextBox();
            MailTextBox = new TextBox();
            PhoneTextBox = new TextBox();
            FIOTextBox = new TextBox();
            SuspendLayout();
            // 
            // CanselButton
            // 
            CanselButton.Location = new Point(370, 133);
            CanselButton.Name = "CanselButton";
            CanselButton.Size = new Size(103, 40);
            CanselButton.TabIndex = 19;
            CanselButton.Text = "Отмена";
            CanselButton.UseVisualStyleBackColor = true;
            CanselButton.Click += CanselButton_Click;
            // 
            // SaveButton
            // 
            SaveButton.Location = new Point(12, 133);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(111, 40);
            SaveButton.TabIndex = 18;
            SaveButton.Text = "Сохранить";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 99);
            label4.Name = "label4";
            label4.Size = new Size(49, 15);
            label4.TabIndex = 17;
            label4.Text = "Адресс:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 69);
            label3.Name = "label3";
            label3.Size = new Size(44, 15);
            label3.TabIndex = 16;
            label3.Text = "Почта:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 42);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 15;
            label2.Text = "Телефон:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 15);
            label1.Name = "label1";
            label1.Size = new Size(84, 15);
            label1.TabIndex = 14;
            label1.Text = "ФИО хозяина:";
            // 
            // AdressTextBox
            // 
            AdressTextBox.Location = new Point(67, 90);
            AdressTextBox.MaxLength = 60;
            AdressTextBox.Multiline = true;
            AdressTextBox.Name = "AdressTextBox";
            AdressTextBox.Size = new Size(406, 24);
            AdressTextBox.TabIndex = 13;
            // 
            // MailTextBox
            // 
            MailTextBox.Location = new Point(67, 66);
            MailTextBox.MaxLength = 60;
            MailTextBox.Multiline = true;
            MailTextBox.Name = "MailTextBox";
            MailTextBox.Size = new Size(406, 18);
            MailTextBox.TabIndex = 12;
            // 
            // PhoneTextBox
            // 
            PhoneTextBox.Location = new Point(76, 42);
            PhoneTextBox.MaxLength = 20;
            PhoneTextBox.Multiline = true;
            PhoneTextBox.Name = "PhoneTextBox";
            PhoneTextBox.Size = new Size(395, 18);
            PhoneTextBox.TabIndex = 11;
            // 
            // FIOTextBox
            // 
            FIOTextBox.Location = new Point(102, 12);
            FIOTextBox.MaxLength = 50;
            FIOTextBox.Name = "FIOTextBox";
            FIOTextBox.Size = new Size(369, 23);
            FIOTextBox.TabIndex = 10;
            // 
            // AddOwnerForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(485, 183);
            Controls.Add(CanselButton);
            Controls.Add(SaveButton);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(AdressTextBox);
            Controls.Add(MailTextBox);
            Controls.Add(PhoneTextBox);
            Controls.Add(FIOTextBox);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddOwnerForm";
            Text = "Работа с владельцами";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CanselButton;
        private Button SaveButton;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox AdressTextBox;
        private TextBox MailTextBox;
        private TextBox PhoneTextBox;
        private TextBox FIOTextBox;
    }
}