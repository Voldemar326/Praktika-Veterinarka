﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class DiseasesForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private string userRole;

        // ✔ Правильный конструктор — принимает роль
        public DiseasesForm(string role)
        {
            InitializeComponent();
            userRole = role;

            ApplyPermissions();   // применяем ограничения
            LoadDiseases();       // загружаем данные
        }

        private void LoadDiseases()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            disease_id AS ""ID"",
                            name AS ""Название"",
                            description AS ""Описание"",
                            symptoms AS ""Симптомы"",
                            treatment AS ""Лечение""
                        FROM diseases
                        ORDER BY disease_id;
                    ";

                    using (var adapter = new NpgsqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void AddDisease_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для добавления записей.");
                return;
            }

            AddDiseaseForm form = new AddDiseaseForm();
            if (form.ShowDialog() == DialogResult.OK)
                LoadDiseases();
        }

        private void EditDisease_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для редактирования записей.");
                return;
            }

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите диагноз для редактирования");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

            AddDiseaseForm form = new AddDiseaseForm(id);
            if (form.ShowDialog() == DialogResult.OK)
                LoadDiseases();
        }

        private void DeleteDisease_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для удаления записей.");
                return;
            }

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите диагноз для удаления");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

            if (MessageBox.Show("Удалить диагноз?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "DELETE FROM diseases WHERE disease_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                LoadDiseases();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message);
            }
        }

        // ✔ Ограничения по роли
        private void ApplyPermissions()
        {
            if (userRole == "vet")
            {
                if (AddDisease != null)
                    AddDisease.Enabled = false;

                if (EditDisease != null)
                    EditDisease.Enabled = false;

                if (DeleteDisease != null)
                    DeleteDisease.Enabled = false;
            }
        }
    }
}
