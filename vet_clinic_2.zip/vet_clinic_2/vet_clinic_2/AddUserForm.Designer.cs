﻿namespace vet_clinic_2
{
    partial class AddUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddUserForm));
            CanselButton = new Button();
            SaveButton = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            PasswordTextBox = new TextBox();
            LoginTextBox = new TextBox();
            DateTimePicker1 = new DateTimePicker();
            RoleComboBox = new ComboBox();
            SuspendLayout();
            // 
            // CanselButton
            // 
            CanselButton.Location = new Point(359, 137);
            CanselButton.Name = "CanselButton";
            CanselButton.Size = new Size(103, 40);
            CanselButton.TabIndex = 19;
            CanselButton.Text = "Отмена";
            CanselButton.UseVisualStyleBackColor = true;
            CanselButton.Click += CanselButton_Click;
            // 
            // SaveButton
            // 
            SaveButton.Location = new Point(14, 137);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(111, 40);
            SaveButton.TabIndex = 18;
            SaveButton.Text = "Сохранить";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(34, 101);
            label4.Name = "label4";
            label4.Size = new Size(88, 15);
            label4.TabIndex = 17;
            label4.Text = "Дата создания:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(85, 71);
            label3.Name = "label3";
            label3.Size = new Size(37, 15);
            label3.TabIndex = 16;
            label3.Text = "Роль:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(70, 40);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 15;
            label2.Text = "Пароль:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(78, 10);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 14;
            label1.Text = "Логин:";
            // 
            // PasswordTextBox
            // 
            PasswordTextBox.Location = new Point(128, 37);
            PasswordTextBox.MaxLength = 25;
            PasswordTextBox.Multiline = true;
            PasswordTextBox.Name = "PasswordTextBox";
            PasswordTextBox.Size = new Size(331, 25);
            PasswordTextBox.TabIndex = 11;
            // 
            // LoginTextBox
            // 
            LoginTextBox.Location = new Point(128, 7);
            LoginTextBox.MaxLength = 25;
            LoginTextBox.Name = "LoginTextBox";
            LoginTextBox.Size = new Size(331, 23);
            LoginTextBox.TabIndex = 10;
            // 
            // DateTimePicker1
            // 
            DateTimePicker1.Location = new Point(131, 101);
            DateTimePicker1.Name = "DateTimePicker1";
            DateTimePicker1.Size = new Size(331, 23);
            DateTimePicker1.TabIndex = 20;
            // 
            // RoleComboBox
            // 
            RoleComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            RoleComboBox.FormattingEnabled = true;
            RoleComboBox.Location = new Point(131, 68);
            RoleComboBox.Name = "RoleComboBox";
            RoleComboBox.Size = new Size(328, 23);
            RoleComboBox.TabIndex = 21;
            // 
            // AddUserForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(474, 195);
            Controls.Add(RoleComboBox);
            Controls.Add(DateTimePicker1);
            Controls.Add(CanselButton);
            Controls.Add(SaveButton);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(PasswordTextBox);
            Controls.Add(LoginTextBox);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddUserForm";
            Text = "Работа с пользователями";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CanselButton;
        private Button SaveButton;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox PasswordTextBox;
        private TextBox LoginTextBox;
        private DateTimePicker DateTimePicker1;
        private ComboBox RoleComboBox;
    }
}