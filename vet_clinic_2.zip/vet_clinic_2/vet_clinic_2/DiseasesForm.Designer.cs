﻿namespace vet_clinic_2
{
    partial class DiseasesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DiseasesForm));
            dataGridView1 = new DataGridView();
            AddDisease = new Button();
            EditDisease = new Button();
            DeleteDisease = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(461, 253);
            dataGridView1.TabIndex = 0;
            // 
            // AddDisease
            // 
            AddDisease.Location = new Point(12, 271);
            AddDisease.Name = "AddDisease";
            AddDisease.Size = new Size(116, 53);
            AddDisease.TabIndex = 1;
            AddDisease.Text = "Добавить диагноз";
            AddDisease.UseVisualStyleBackColor = true;
            AddDisease.Click += AddDisease_Click;
            // 
            // EditDisease
            // 
            EditDisease.Location = new Point(168, 271);
            EditDisease.Name = "EditDisease";
            EditDisease.Size = new Size(149, 53);
            EditDisease.TabIndex = 2;
            EditDisease.Text = "Редактировать Диагноз";
            EditDisease.UseVisualStyleBackColor = true;
            EditDisease.Click += EditDisease_Click;
            // 
            // DeleteDisease
            // 
            DeleteDisease.Location = new Point(353, 271);
            DeleteDisease.Name = "DeleteDisease";
            DeleteDisease.Size = new Size(120, 53);
            DeleteDisease.TabIndex = 3;
            DeleteDisease.Text = "Удалить Диагноз";
            DeleteDisease.UseVisualStyleBackColor = true;
            DeleteDisease.Click += DeleteDisease_Click;
            // 
            // DiseasesForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(479, 361);
            Controls.Add(DeleteDisease);
            Controls.Add(EditDisease);
            Controls.Add(AddDisease);
            Controls.Add(dataGridView1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "DiseasesForm";
            Text = "Просмотр диагнозов";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private Button AddDisease;
        private Button EditDisease;
        private Button DeleteDisease;
    }
}