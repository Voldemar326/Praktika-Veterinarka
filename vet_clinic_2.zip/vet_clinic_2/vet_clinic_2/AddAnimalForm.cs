﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class AddAnimalForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private int? animalId = null; 


        public AddAnimalForm()
        {
            InitializeComponent();
            LoadOwners(); 
        }

        public AddAnimalForm(int id)
        {
            InitializeComponent();
            animalId = id;
            LoadOwners();     
            LoadAnimalData(); 
        }


        private void LoadOwners()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"SELECT owner_id, full_name FROM owners ORDER BY full_name";

                    using (var adapter = new NpgsqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        comboBoxOwner.DataSource = dt;
                        comboBoxOwner.DisplayMember = "full_name";
                        comboBoxOwner.ValueMember = "owner_id";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки владельцев: " + ex.Message);
            }
        }


        private void LoadAnimalData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"SELECT name, species, breed, sex, birth_date, owner_id, notes
                                   FROM animals 
                                   WHERE animal_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", animalId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                NameTextBox.Text = reader.GetString(0);
                                SpeciesTextBox.Text = reader.IsDBNull(1) ? "" : reader.GetString(1);
                                BreedTextBox.Text = reader.IsDBNull(2) ? "" : reader.GetString(2);
                                comboBoxSex.Text = reader.IsDBNull(3) ? "" : reader.GetString(3);
                                dateTimePickerBirth.Value = reader.IsDBNull(4) ? DateTime.Now : reader.GetDateTime(4);

                                if (!reader.IsDBNull(5))
                                    comboBoxOwner.SelectedValue = reader.GetInt32(5);

                                textBoxNotes.Text = reader.IsDBNull(6) ? "" : reader.GetString(6);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных животного: " + ex.Message);
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string name = NameTextBox.Text.Trim();
            string species = SpeciesTextBox.Text.Trim();
            string breed = BreedTextBox.Text.Trim();
            string sex = comboBoxSex.Text.Trim();
            DateTime birth = dateTimePickerBirth.Value;
            int ownerId = Convert.ToInt32(comboBoxOwner.SelectedValue);
            string notes = textBoxNotes.Text.Trim();

            if (name == "")
            {
                MessageBox.Show("Введите кличку животного");
                return;
            }

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql;

                    if (animalId == null)
                    {

                        sql = @"INSERT INTO animals 
                                (name, species, breed, sex, birth_date, owner_id, notes)
                                VALUES (@n, @s, @b, @x, @d, @o, @t)";
                    }
                    else
                    {

                        sql = @"UPDATE animals
                                SET name=@n, species=@s, breed=@b, sex=@x, birth_date=@d, owner_id=@o, notes=@t
                                WHERE animal_id=@id";
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("n", name);
                        cmd.Parameters.AddWithValue("s", (object)species ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("b", (object)breed ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("x", (object)sex ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("d", birth);
                        cmd.Parameters.AddWithValue("o", ownerId);
                        cmd.Parameters.AddWithValue("t", (object)notes ?? DBNull.Value);

                        if (animalId != null)
                            cmd.Parameters.AddWithValue("id", animalId);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message);
            }
        }

        private void CanselButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void AddAnimalForm_Load(object sender, EventArgs e)
        {

        }

    }
}
