﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class AboutFormSpravka : Form
    {
        public AboutFormSpravka()
        {
            InitializeComponent();
        }
    }
}
