﻿namespace vet_clinic_2
{
    partial class AddVetForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CanselButton = new Button();
            SaveButton = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            SpecificationTextBox = new TextBox();
            MailTextBox = new TextBox();
            PhoneTextBox = new TextBox();
            FIOTextBox = new TextBox();
            label5 = new Label();
            StazTextBox = new TextBox();
            SuspendLayout();
            // 
            // CanselButton
            // 
            CanselButton.Location = new Point(372, 150);
            CanselButton.Name = "CanselButton";
            CanselButton.Size = new Size(103, 40);
            CanselButton.TabIndex = 29;
            CanselButton.Text = "Отмена";
            CanselButton.UseVisualStyleBackColor = true;
            CanselButton.Click += CanselButton_Click;
            // 
            // SaveButton
            // 
            SaveButton.Location = new Point(12, 150);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(111, 40);
            SaveButton.TabIndex = 28;
            SaveButton.Text = "Сохранить";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(14, 44);
            label4.Name = "label4";
            label4.Size = new Size(96, 15);
            label4.TabIndex = 27;
            label4.Text = "Специализация:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(14, 129);
            label3.Name = "label3";
            label3.Size = new Size(44, 15);
            label3.TabIndex = 26;
            label3.Text = "Почта:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 102);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 25;
            label2.Text = "Телефон:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(14, 15);
            label1.Name = "label1";
            label1.Size = new Size(103, 15);
            label1.TabIndex = 24;
            label1.Text = "ФИО ветеринара:";
            // 
            // SpecificationTextBox
            // 
            SpecificationTextBox.Location = new Point(116, 41);
            SpecificationTextBox.Multiline = true;
            SpecificationTextBox.Name = "SpecificationTextBox";
            SpecificationTextBox.Size = new Size(359, 24);
            SpecificationTextBox.TabIndex = 23;
            // 
            // MailTextBox
            // 
            MailTextBox.Location = new Point(69, 126);
            MailTextBox.Multiline = true;
            MailTextBox.Name = "MailTextBox";
            MailTextBox.Size = new Size(406, 18);
            MailTextBox.TabIndex = 22;
            // 
            // PhoneTextBox
            // 
            PhoneTextBox.Location = new Point(80, 102);
            PhoneTextBox.Multiline = true;
            PhoneTextBox.Name = "PhoneTextBox";
            PhoneTextBox.Size = new Size(395, 18);
            PhoneTextBox.TabIndex = 21;
            // 
            // FIOTextBox
            // 
            FIOTextBox.Location = new Point(123, 12);
            FIOTextBox.Name = "FIOTextBox";
            FIOTextBox.Size = new Size(352, 23);
            FIOTextBox.TabIndex = 20;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(20, 74);
            label5.Name = "label5";
            label5.Size = new Size(38, 15);
            label5.TabIndex = 31;
            label5.Text = "Стаж:";
            // 
            // StazTextBox
            // 
            StazTextBox.Location = new Point(64, 71);
            StazTextBox.Multiline = true;
            StazTextBox.Name = "StazTextBox";
            StazTextBox.Size = new Size(411, 24);
            StazTextBox.TabIndex = 30;
            // 
            // AddVetForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(480, 196);
            Controls.Add(label5);
            Controls.Add(StazTextBox);
            Controls.Add(CanselButton);
            Controls.Add(SaveButton);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(SpecificationTextBox);
            Controls.Add(MailTextBox);
            Controls.Add(PhoneTextBox);
            Controls.Add(FIOTextBox);
            Name = "AddVetForm";
            Text = "AddVetForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CanselButton;
        private Button SaveButton;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox SpecificationTextBox;
        private TextBox MailTextBox;
        private TextBox PhoneTextBox;
        private TextBox FIOTextBox;
        private Label label5;
        private TextBox StazTextBox;
    }
}