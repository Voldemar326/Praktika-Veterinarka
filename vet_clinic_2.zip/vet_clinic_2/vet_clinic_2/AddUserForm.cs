﻿using Npgsql;
using System;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class AddUserForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private int? userId = null;

        public AddUserForm()
        {
            InitializeComponent();
            InitRoles();
            DateTimePicker1.Value = DateTime.Now;
        }

        public AddUserForm(int id)
        {
            InitializeComponent();
            userId = id;

            InitRoles();
            LoadUserData();
        }

        private void InitRoles()
        {
            RoleComboBox.Items.Clear();
            RoleComboBox.Items.Add("Администратор"); 
            RoleComboBox.Items.Add("Ветеринар");    
            RoleComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            RoleComboBox.SelectedIndex = 0;
        }

        private void LoadUserData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"SELECT username, password_hash, role, created_at 
                                   FROM users 
                                   WHERE user_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", userId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                LoginTextBox.Text = reader.GetString(0);
                                PasswordTextBox.Text = reader.GetString(1);

                                bool role = reader.GetBoolean(2);
                                RoleComboBox.SelectedIndex = role ? 0 : 1;

                                DateTimePicker1.Value = reader.GetDateTime(3);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки пользователя: " + ex.Message);
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string username = LoginTextBox.Text.Trim();
            string password = PasswordTextBox.Text.Trim();
            bool role = RoleComboBox.SelectedIndex == 0;
            DateTime createdAt = DateTimePicker1.Value;

            if (username == "")
            {
                MessageBox.Show("Введите логин");
                return;
            }

            if (password == "")
            {
                MessageBox.Show("Введите пароль");
                return;
            }

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql;

                    if (userId == null)
                    {
                        sql = @"
                            INSERT INTO users (username, password_hash, role, created_at)
                            VALUES (@u, @p, @r, @c)
                        ";
                    }
                    else
                    {
                        sql = @"
                            UPDATE users
                            SET username=@u, password_hash=@p, role=@r, created_at=@c
                            WHERE user_id=@id
                        ";
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("u", username);
                        cmd.Parameters.AddWithValue("p", password);
                        cmd.Parameters.AddWithValue("r", role);
                        cmd.Parameters.AddWithValue("c", createdAt);

                        if (userId != null)
                            cmd.Parameters.AddWithValue("id", userId);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message);
            }
        }

        private void CanselButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
