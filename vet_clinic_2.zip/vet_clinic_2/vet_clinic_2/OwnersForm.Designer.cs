﻿namespace vet_clinic_2
{
    partial class OwnersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OwnersForm));
            DeleteOwner = new Button();
            EditOwner = new Button();
            AddOwner = new Button();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // DeleteOwner
            // 
            DeleteOwner.Location = new Point(353, 262);
            DeleteOwner.Name = "DeleteOwner";
            DeleteOwner.Size = new Size(120, 53);
            DeleteOwner.TabIndex = 7;
            DeleteOwner.Text = "Удалить владельца";
            DeleteOwner.UseVisualStyleBackColor = true;
            DeleteOwner.Click += DeleteOwner_Click;
            // 
            // EditOwner
            // 
            EditOwner.Location = new Point(168, 262);
            EditOwner.Name = "EditOwner";
            EditOwner.Size = new Size(149, 53);
            EditOwner.TabIndex = 6;
            EditOwner.Text = "Редактировать владельца";
            EditOwner.UseVisualStyleBackColor = true;
            EditOwner.Click += EditOwner_Click;
            // 
            // AddOwner
            // 
            AddOwner.Location = new Point(12, 262);
            AddOwner.Name = "AddOwner";
            AddOwner.Size = new Size(116, 53);
            AddOwner.TabIndex = 5;
            AddOwner.Text = "Добавить владельца";
            AddOwner.UseVisualStyleBackColor = true;
            AddOwner.Click += AddOwner_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(461, 253);
            dataGridView1.TabIndex = 4;
            // 
            // OwnersForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(495, 324);
            Controls.Add(DeleteOwner);
            Controls.Add(EditOwner);
            Controls.Add(AddOwner);
            Controls.Add(dataGridView1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "OwnersForm";
            Text = "Просмотр владельцев";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button DeleteOwner;
        private Button EditOwner;
        private Button AddOwner;
        private DataGridView dataGridView1;
    }
}