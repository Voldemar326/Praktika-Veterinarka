﻿namespace vet_clinic_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            dataGridView1 = new DataGridView();
            Exitbutton = new Button();
            AddRecordButton = new Button();
            EditRecordButton = new Button();
            DeleteRecordButton = new Button();
            DirectoryOpenButton = new Button();
            AdminEditButton = new Button();
            SearchButton = new Button();
            textBoxSearch = new TextBox();
            comboBoxSearchBy = new ComboBox();
            comboBoxSex = new ComboBox();
            comboBoxSpecies = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            groupBox1 = new GroupBox();
            label17 = new Label();
            RecordTime = new TextBox();
            label16 = new Label();
            RecordType = new TextBox();
            label15 = new Label();
            AnimalAnnotation = new TextBox();
            label14 = new Label();
            VetMail = new TextBox();
            label13 = new Label();
            Disease = new TextBox();
            label11 = new Label();
            VetPhone = new TextBox();
            label12 = new Label();
            VetFullName = new TextBox();
            label10 = new Label();
            OwnerMail = new TextBox();
            label9 = new Label();
            OwnerPhone = new TextBox();
            label8 = new Label();
            label4 = new Label();
            label7 = new Label();
            AnimalType = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label3 = new Label();
            OwnerFullName = new TextBox();
            BirthDate = new TextBox();
            AnimalSex = new TextBox();
            AnimalBreed = new TextBox();
            AnimalName = new TextBox();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(281, 201);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(709, 491);
            dataGridView1.TabIndex = 0;
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
            // 
            // Exitbutton
            // 
            Exitbutton.Location = new Point(12, 662);
            Exitbutton.Name = "Exitbutton";
            Exitbutton.Size = new Size(83, 30);
            Exitbutton.TabIndex = 1;
            Exitbutton.Text = "Выход";
            Exitbutton.UseVisualStyleBackColor = true;
            Exitbutton.Click += Exitbutton_Click;
            // 
            // AddRecordButton
            // 
            AddRecordButton.Location = new Point(281, 12);
            AddRecordButton.Name = "AddRecordButton";
            AddRecordButton.Size = new Size(109, 35);
            AddRecordButton.TabIndex = 2;
            AddRecordButton.Text = "Добавить запись";
            AddRecordButton.UseVisualStyleBackColor = true;
            AddRecordButton.Click += AddRecordButton_Click;
            // 
            // EditRecordButton
            // 
            EditRecordButton.Location = new Point(396, 12);
            EditRecordButton.Name = "EditRecordButton";
            EditRecordButton.Size = new Size(109, 35);
            EditRecordButton.TabIndex = 3;
            EditRecordButton.Text = "Изменить запись";
            EditRecordButton.UseVisualStyleBackColor = true;
            EditRecordButton.Click += EditRecordButton_Click;
            // 
            // DeleteRecordButton
            // 
            DeleteRecordButton.Location = new Point(511, 12);
            DeleteRecordButton.Name = "DeleteRecordButton";
            DeleteRecordButton.Size = new Size(109, 35);
            DeleteRecordButton.TabIndex = 4;
            DeleteRecordButton.Text = "Удалть запись";
            DeleteRecordButton.UseVisualStyleBackColor = true;
            DeleteRecordButton.Click += DeleteRecordButton_Click;
            // 
            // DirectoryOpenButton
            // 
            DirectoryOpenButton.Location = new Point(881, 12);
            DirectoryOpenButton.Name = "DirectoryOpenButton";
            DirectoryOpenButton.Size = new Size(109, 35);
            DirectoryOpenButton.TabIndex = 5;
            DirectoryOpenButton.Text = "Справочник";
            DirectoryOpenButton.UseVisualStyleBackColor = true;
            DirectoryOpenButton.Click += DirectoryOpenButton_Click;
            // 
            // AdminEditButton
            // 
            AdminEditButton.Location = new Point(881, 53);
            AdminEditButton.Name = "AdminEditButton";
            AdminEditButton.Size = new Size(109, 41);
            AdminEditButton.TabIndex = 6;
            AdminEditButton.Text = "Работа с пользователями";
            AdminEditButton.UseVisualStyleBackColor = true;
            AdminEditButton.Click += AdminEditButton_Click;
            // 
            // SearchButton
            // 
            SearchButton.Location = new Point(881, 160);
            SearchButton.Name = "SearchButton";
            SearchButton.Size = new Size(109, 35);
            SearchButton.TabIndex = 8;
            SearchButton.Text = "Обновить";
            SearchButton.UseVisualStyleBackColor = true;
            SearchButton.Click += SearchButton_Click;
            // 
            // textBoxSearch
            // 
            textBoxSearch.Location = new Point(281, 172);
            textBoxSearch.MaxLength = 40;
            textBoxSearch.Name = "textBoxSearch";
            textBoxSearch.Size = new Size(212, 23);
            textBoxSearch.TabIndex = 9;
            // 
            // comboBoxSearchBy
            // 
            comboBoxSearchBy.FormattingEnabled = true;
            comboBoxSearchBy.Location = new Point(499, 172);
            comboBoxSearchBy.Name = "comboBoxSearchBy";
            comboBoxSearchBy.Size = new Size(121, 23);
            comboBoxSearchBy.TabIndex = 10;
            // 
            // comboBoxSex
            // 
            comboBoxSex.FormattingEnabled = true;
            comboBoxSex.Location = new Point(627, 172);
            comboBoxSex.Name = "comboBoxSex";
            comboBoxSex.Size = new Size(121, 23);
            comboBoxSex.TabIndex = 11;
            // 
            // comboBoxSpecies
            // 
            comboBoxSpecies.FormattingEnabled = true;
            comboBoxSpecies.Location = new Point(754, 172);
            comboBoxSpecies.Name = "comboBoxSpecies";
            comboBoxSpecies.Size = new Size(121, 23);
            comboBoxSpecies.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(281, 154);
            label1.Name = "label1";
            label1.Size = new Size(45, 15);
            label1.TabIndex = 13;
            label1.Text = "Поиск:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(499, 154);
            label2.Name = "label2";
            label2.Size = new Size(26, 15);
            label2.TabIndex = 14;
            label2.Text = "По:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label17);
            groupBox1.Controls.Add(RecordTime);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(RecordType);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(AnimalAnnotation);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(VetMail);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(Disease);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(VetPhone);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(VetFullName);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(OwnerMail);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(OwnerPhone);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(AnimalType);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(OwnerFullName);
            groupBox1.Controls.Add(BirthDate);
            groupBox1.Controls.Add(AnimalSex);
            groupBox1.Controls.Add(AnimalBreed);
            groupBox1.Controls.Add(AnimalName);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(263, 644);
            groupBox1.TabIndex = 15;
            groupBox1.TabStop = false;
            groupBox1.Text = "Выбраная запись";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(6, 471);
            label17.Name = "label17";
            label17.Size = new Size(86, 15);
            label17.TabIndex = 41;
            label17.Text = "Время записи:";
            // 
            // RecordTime
            // 
            RecordTime.Location = new Point(90, 468);
            RecordTime.Name = "RecordTime";
            RecordTime.ReadOnly = true;
            RecordTime.Size = new Size(167, 23);
            RecordTime.TabIndex = 40;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(6, 442);
            label16.Name = "label16";
            label16.Size = new Size(71, 15);
            label16.TabIndex = 39;
            label16.Text = "Тип записи:";
            // 
            // RecordType
            // 
            RecordType.Location = new Point(76, 439);
            RecordType.Name = "RecordType";
            RecordType.ReadOnly = true;
            RecordType.Size = new Size(181, 23);
            RecordType.TabIndex = 38;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(6, 503);
            label15.Name = "label15";
            label15.Size = new Size(144, 15);
            label15.TabIndex = 37;
            label15.Text = "Примечания животного:";
            // 
            // AnimalAnnotation
            // 
            AnimalAnnotation.Location = new Point(6, 521);
            AnimalAnnotation.Multiline = true;
            AnimalAnnotation.Name = "AnimalAnnotation";
            AnimalAnnotation.ReadOnly = true;
            AnimalAnnotation.Size = new Size(251, 117);
            AnimalAnnotation.TabIndex = 36;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(6, 363);
            label14.Name = "label14";
            label14.Size = new Size(110, 15);
            label14.TabIndex = 35;
            label14.Text = "Почта ветеринара:";
            // 
            // VetMail
            // 
            VetMail.Location = new Point(6, 381);
            VetMail.Name = "VetMail";
            VetMail.ReadOnly = true;
            VetMail.Size = new Size(251, 23);
            VetMail.TabIndex = 34;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(6, 413);
            label13.Name = "label13";
            label13.Size = new Size(55, 15);
            label13.TabIndex = 33;
            label13.Text = "Диагноз:";
            // 
            // Disease
            // 
            Disease.Location = new Point(67, 410);
            Disease.Name = "Disease";
            Disease.ReadOnly = true;
            Disease.Size = new Size(190, 23);
            Disease.TabIndex = 32;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(6, 317);
            label11.Name = "label11";
            label11.Size = new Size(124, 15);
            label11.TabIndex = 31;
            label11.Text = "Телефон ветеринара:";
            // 
            // VetPhone
            // 
            VetPhone.Location = new Point(6, 335);
            VetPhone.Name = "VetPhone";
            VetPhone.ReadOnly = true;
            VetPhone.Size = new Size(251, 23);
            VetPhone.TabIndex = 30;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(6, 269);
            label12.Name = "label12";
            label12.Size = new Size(103, 15);
            label12.TabIndex = 29;
            label12.Text = "ФИО ветеринара:";
            // 
            // VetFullName
            // 
            VetFullName.Location = new Point(6, 287);
            VetFullName.Name = "VetFullName";
            VetFullName.ReadOnly = true;
            VetFullName.Size = new Size(251, 23);
            VetFullName.TabIndex = 28;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(6, 225);
            label10.Name = "label10";
            label10.Size = new Size(104, 15);
            label10.TabIndex = 27;
            label10.Text = "Почта владельца:";
            // 
            // OwnerMail
            // 
            OwnerMail.Location = new Point(6, 243);
            OwnerMail.Name = "OwnerMail";
            OwnerMail.ReadOnly = true;
            OwnerMail.Size = new Size(251, 23);
            OwnerMail.TabIndex = 26;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 183);
            label9.Name = "label9";
            label9.Size = new Size(118, 15);
            label9.TabIndex = 25;
            label9.Text = "Телефон владельца:";
            // 
            // OwnerPhone
            // 
            OwnerPhone.Location = new Point(6, 201);
            OwnerPhone.Name = "OwnerPhone";
            OwnerPhone.ReadOnly = true;
            OwnerPhone.Size = new Size(251, 23);
            OwnerPhone.TabIndex = 24;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 135);
            label8.Name = "label8";
            label8.Size = new Size(97, 15);
            label8.TabIndex = 23;
            label8.Text = "ФИО владельца:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 112);
            label4.Name = "label4";
            label4.Size = new Size(93, 15);
            label4.TabIndex = 22;
            label4.Text = "Дата рождения:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(13, 54);
            label7.Name = "label7";
            label7.Size = new Size(30, 15);
            label7.TabIndex = 21;
            label7.Text = "Вид:";
            // 
            // AnimalType
            // 
            AnimalType.Location = new Point(52, 51);
            AnimalType.Name = "AnimalType";
            AnimalType.ReadOnly = true;
            AnimalType.Size = new Size(75, 23);
            AnimalType.TabIndex = 20;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(133, 54);
            label6.Name = "label6";
            label6.Size = new Size(33, 15);
            label6.TabIndex = 19;
            label6.Text = "Пол:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(18, 80);
            label5.Name = "label5";
            label5.Size = new Size(52, 15);
            label5.TabIndex = 18;
            label5.Text = "Порода:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(20, 25);
            label3.Name = "label3";
            label3.Size = new Size(50, 15);
            label3.TabIndex = 16;
            label3.Text = "Кличка:";
            // 
            // OwnerFullName
            // 
            OwnerFullName.Location = new Point(6, 153);
            OwnerFullName.Name = "OwnerFullName";
            OwnerFullName.ReadOnly = true;
            OwnerFullName.Size = new Size(251, 23);
            OwnerFullName.TabIndex = 5;
            // 
            // BirthDate
            // 
            BirthDate.Location = new Point(105, 109);
            BirthDate.Name = "BirthDate";
            BirthDate.ReadOnly = true;
            BirthDate.Size = new Size(152, 23);
            BirthDate.TabIndex = 4;
            // 
            // AnimalSex
            // 
            AnimalSex.Location = new Point(172, 51);
            AnimalSex.Name = "AnimalSex";
            AnimalSex.ReadOnly = true;
            AnimalSex.Size = new Size(85, 23);
            AnimalSex.TabIndex = 3;
            // 
            // AnimalBreed
            // 
            AnimalBreed.Location = new Point(76, 80);
            AnimalBreed.Name = "AnimalBreed";
            AnimalBreed.ReadOnly = true;
            AnimalBreed.Size = new Size(181, 23);
            AnimalBreed.TabIndex = 2;
            // 
            // AnimalName
            // 
            AnimalName.Location = new Point(76, 22);
            AnimalName.Name = "AnimalName";
            AnimalName.ReadOnly = true;
            AnimalName.Size = new Size(181, 23);
            AnimalName.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(770, 12);
            button1.Name = "button1";
            button1.Size = new Size(105, 35);
            button1.TabIndex = 16;
            button1.Text = "Справка";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1002, 704);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(comboBoxSpecies);
            Controls.Add(comboBoxSex);
            Controls.Add(comboBoxSearchBy);
            Controls.Add(textBoxSearch);
            Controls.Add(SearchButton);
            Controls.Add(AdminEditButton);
            Controls.Add(DirectoryOpenButton);
            Controls.Add(DeleteRecordButton);
            Controls.Add(EditRecordButton);
            Controls.Add(AddRecordButton);
            Controls.Add(Exitbutton);
            Controls.Add(dataGridView1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Записи";
            FormClosing += Form1_FormClosing;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button Exitbutton;
        private Button AddRecordButton;
        private Button EditRecordButton;
        private Button DeleteRecordButton;
        private Button DirectoryOpenButton;
        private Button AdminEditButton;
        private Button SearchButton;
        private TextBox textBoxSearch;
        private ComboBox comboBoxSearchBy;
        private ComboBox comboBoxSex;
        private ComboBox comboBoxSpecies;
        private Label label1;
        private Label label2;
        private GroupBox groupBox1;
        private TextBox OwnerFullName;
        private TextBox BirthDate;
        private TextBox AnimalName;
        private TextBox AnimalBreed;
        private TextBox AnimalSex;
        private Label label7;
        private TextBox AnimalType;
        private Label label6;
        private Label label5;
        private Label label3;
        private Label label15;
        private TextBox AnimalAnnotation;
        private Label label14;
        private TextBox VetMail;
        private Label label13;
        private TextBox Disease;
        private Label label11;
        private TextBox VetPhone;
        private Label label12;
        private TextBox VetFullName;
        private Label label10;
        private TextBox OwnerMail;
        private Label label9;
        private TextBox OwnerPhone;
        private Label label8;
        private Label label4;
        private Label label17;
        private TextBox RecordTime;
        private Label label16;
        private TextBox RecordType;
        private Button button1;
    }
}