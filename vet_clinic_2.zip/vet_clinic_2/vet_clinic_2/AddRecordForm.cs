﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class AddRecordForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private int? recordId = null; // null = добавление, число = редактирование

        // Режим добавления
        public AddRecordForm()
        {
            InitializeComponent();
            LoadAnimals();
            LoadVets();
            LoadDiagnoses();
            LoadTypes();
        }

        // Режим редактирования
        public AddRecordForm(int id)
        {
            InitializeComponent();
            recordId = id;

            LoadAnimals();
            LoadVets();
            LoadDiagnoses();
            LoadTypes();

            LoadRecordData();
        }

        // ------------------ ЗАГРУЗКА СПРАВОЧНИКОВ ------------------

        private void LoadAnimals()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string sql = @"SELECT animal_id, name FROM animals ORDER BY name";

                    using (var adapter = new NpgsqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        comboBoxAnimal.DataSource = dt;
                        comboBoxAnimal.DisplayMember = "name";
                        comboBoxAnimal.ValueMember = "animal_id";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки животных: " + ex.Message);
            }
        }

        private void LoadVets()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string sql = @"SELECT vet_id, full_name FROM vets ORDER BY full_name";

                    using (var adapter = new NpgsqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        comboBoxVet.DataSource = dt;
                        comboBoxVet.DisplayMember = "full_name";
                        comboBoxVet.ValueMember = "vet_id";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки ветеринаров: " + ex.Message);
            }
        }

        private void LoadDiagnoses()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string sql = @"SELECT disease_id, name FROM diseases ORDER BY name";

                    using (var adapter = new NpgsqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        comboBoxDiagnosis.DataSource = dt;
                        comboBoxDiagnosis.DisplayMember = "name";
                        comboBoxDiagnosis.ValueMember = "disease_id";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки диагнозов: " + ex.Message);
            }
        }

        private void LoadTypes()
        {
            comboBoxType.Items.Clear();
            comboBoxType.Items.Add("Первичный приём");
            comboBoxType.Items.Add("Повторный приём");
            comboBoxType.Items.Add("Вакцинация");
            comboBoxType.Items.Add("Операция");
            comboBoxType.Items.Add("Осмотр");
            comboBoxType.SelectedIndex = 0;
        }

        // ------------------ ЗАГРУЗКА ДАННЫХ ПРИ РЕДАКТИРОВАНИИ ------------------

        private void LoadRecordData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT animal_id, vet_id, record_date, type, diagnosis_id, description, cost
                        FROM records
                        WHERE record_id=@id
                    ";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", recordId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                comboBoxAnimal.SelectedValue = reader.GetInt32(0);
                                comboBoxVet.SelectedValue = reader.GetInt32(1);
                                dateTimePickerDate.Value = reader.GetDateTime(2);
                                comboBoxType.Text = reader.GetString(3);

                                if (!reader.IsDBNull(4))
                                    comboBoxDiagnosis.SelectedValue = reader.GetInt32(4);

                                textBoxDescription.Text = reader.IsDBNull(5) ? "" : reader.GetString(5);
                                textBoxCost.Text = reader.IsDBNull(6) ? "" : reader.GetDecimal(6).ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки записи: " + ex.Message);
            }
        }

        // ------------------ СОХРАНЕНИЕ ------------------

        private void SaveButton_Click(object sender, EventArgs e)
        {
            int animalId = Convert.ToInt32(comboBoxAnimal.SelectedValue);
            int vetId = Convert.ToInt32(comboBoxVet.SelectedValue);
            DateTime date = dateTimePickerDate.Value;
            string type = comboBoxType.Text;
            int? diagnosisId = comboBoxDiagnosis.SelectedValue as int?;
            string description = textBoxDescription.Text.Trim();

            decimal cost = 0;
            decimal.TryParse(textBoxCost.Text, out cost);

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql;

                    if (recordId == null)
                    {
                        sql = @"
                            INSERT INTO records
                            (animal_id, vet_id, record_date, type, diagnosis_id, description, cost)
                            VALUES (@a, @v, @d, @t, @diag, @desc, @c)
                        ";
                    }
                    else
                    {
                        sql = @"
                            UPDATE records
                            SET animal_id=@a, vet_id=@v, record_date=@d, type=@t,
                                diagnosis_id=@diag, description=@desc, cost=@c
                            WHERE record_id=@id
                        ";
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("a", animalId);
                        cmd.Parameters.AddWithValue("v", vetId);
                        cmd.Parameters.AddWithValue("d", date);
                        cmd.Parameters.AddWithValue("t", type);
                        cmd.Parameters.AddWithValue("diag", (object)diagnosisId ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("desc", (object)description ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("c", cost);

                        if (recordId != null)
                            cmd.Parameters.AddWithValue("id", recordId);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message);
            }
        }

        private void CanselButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
