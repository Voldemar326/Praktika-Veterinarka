﻿namespace vet_clinic_2
{
    partial class AnimalsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AnimalsForm));
            DeleteAnimal = new Button();
            EditAnimal = new Button();
            AddAnimal = new Button();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // DeleteAnimal
            // 
            DeleteAnimal.Location = new Point(353, 271);
            DeleteAnimal.Name = "DeleteAnimal";
            DeleteAnimal.Size = new Size(120, 53);
            DeleteAnimal.TabIndex = 11;
            DeleteAnimal.Text = "Удалить питомца";
            DeleteAnimal.UseVisualStyleBackColor = true;
            DeleteAnimal.Click += DeleteAnimal_Click;
            // 
            // EditAnimal
            // 
            EditAnimal.Location = new Point(168, 271);
            EditAnimal.Name = "EditAnimal";
            EditAnimal.Size = new Size(149, 53);
            EditAnimal.TabIndex = 10;
            EditAnimal.Text = "Редактировать питомца";
            EditAnimal.UseVisualStyleBackColor = true;
            EditAnimal.Click += EditAnimal_Click;
            // 
            // AddAnimal
            // 
            AddAnimal.Location = new Point(12, 271);
            AddAnimal.Name = "AddAnimal";
            AddAnimal.Size = new Size(116, 53);
            AddAnimal.TabIndex = 9;
            AddAnimal.Text = "Добавить питомца";
            AddAnimal.UseVisualStyleBackColor = true;
            AddAnimal.Click += AddAnimal_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(461, 253);
            dataGridView1.TabIndex = 8;
            // 
            // AnimalsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(500, 352);
            Controls.Add(DeleteAnimal);
            Controls.Add(EditAnimal);
            Controls.Add(AddAnimal);
            Controls.Add(dataGridView1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AnimalsForm";
            Text = "AnimalsForm";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button DeleteAnimal;
        private Button EditAnimal;
        private Button AddAnimal;
        private DataGridView dataGridView1;
    }
}