﻿using Npgsql;
using System;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class AddVetForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private int? vetId = null; // null = добавление, число = редактирование

        // Режим добавления
        public AddVetForm()
        {
            InitializeComponent();
        }

        // Режим редактирования
        public AddVetForm(int id)
        {
            InitializeComponent();
            vetId = id;
            LoadVetData();
        }

        private void LoadVetData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"SELECT full_name, specialization, experience_years, phone, email
                                   FROM vets 
                                   WHERE vet_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", vetId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                FIOTextBox.Text = reader.GetString(0);
                                SpecificationTextBox.Text = reader.IsDBNull(1) ? "" : reader.GetString(1);
                                StazTextBox.Text = reader.IsDBNull(2) ? "" : reader.GetInt32(2).ToString();
                                PhoneTextBox.Text = reader.IsDBNull(3) ? "" : reader.GetString(3);
                                MailTextBox.Text = reader.IsDBNull(4) ? "" : reader.GetString(4);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string fullName = FIOTextBox.Text.Trim();
            string specialization = SpecificationTextBox.Text.Trim();
            string experienceText = StazTextBox.Text.Trim();
            string phone = PhoneTextBox.Text.Trim();
            string email = MailTextBox.Text.Trim();

            if (fullName == "")
            {
                MessageBox.Show("Введите ФИО ветеринара");
                return;
            }

            int? experience = null;
            if (int.TryParse(experienceText, out int exp))
                experience = exp;

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql;

                    if (vetId == null)
                    {
                        // Добавление
                        sql = @"INSERT INTO vets (full_name, specialization, experience_years, phone, email)
                                VALUES (@f, @s, @e, @p, @m)";
                    }
                    else
                    {
                        // Редактирование
                        sql = @"UPDATE vets
                                SET full_name=@f, specialization=@s, experience_years=@e, phone=@p, email=@m
                                WHERE vet_id=@id";
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("f", fullName);
                        cmd.Parameters.AddWithValue("s", (object)specialization ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("e", (object)experience ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("p", (object)phone ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("m", (object)email ?? DBNull.Value);

                        if (vetId != null)
                            cmd.Parameters.AddWithValue("id", vetId);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message);
            }
        }

        private void CanselButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
