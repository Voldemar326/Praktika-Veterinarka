﻿namespace vet_clinic_2
{
    partial class AutorizationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AutorizationForm));
            textBoxLogin = new TextBox();
            textBoxPassword = new TextBox();
            buttonLogin = new Button();
            label1 = new Label();
            label2 = new Label();
            ShowPasswordChekBox = new CheckBox();
            SuspendLayout();
            // 
            // textBoxLogin
            // 
            textBoxLogin.Location = new Point(58, 12);
            textBoxLogin.MaxLength = 30;
            textBoxLogin.Name = "textBoxLogin";
            textBoxLogin.Size = new Size(173, 23);
            textBoxLogin.TabIndex = 0;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(58, 41);
            textBoxPassword.MaxLength = 30;
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(173, 23);
            textBoxPassword.TabIndex = 1;
            // 
            // buttonLogin
            // 
            buttonLogin.Location = new Point(8, 70);
            buttonLogin.Name = "buttonLogin";
            buttonLogin.Size = new Size(102, 34);
            buttonLogin.TabIndex = 3;
            buttonLogin.Text = "вход";
            buttonLogin.UseVisualStyleBackColor = true;
            buttonLogin.Click += buttonLogin_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(8, 20);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 4;
            label1.Text = "Логин:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(0, 44);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 5;
            label2.Text = "Пароль:";
            // 
            // ShowPasswordChekBox
            // 
            ShowPasswordChekBox.AutoSize = true;
            ShowPasswordChekBox.Location = new Point(116, 79);
            ShowPasswordChekBox.Name = "ShowPasswordChekBox";
            ShowPasswordChekBox.Size = new Size(119, 19);
            ShowPasswordChekBox.TabIndex = 6;
            ShowPasswordChekBox.Text = "Показать пароль";
            ShowPasswordChekBox.UseVisualStyleBackColor = true;
            ShowPasswordChekBox.CheckedChanged += ShowPasswordChekBox_CheckedChanged;
            // 
            // AutorizationForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(244, 121);
            Controls.Add(ShowPasswordChekBox);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonLogin);
            Controls.Add(textBoxPassword);
            Controls.Add(textBoxLogin);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AutorizationForm";
            Text = "Вход";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxLogin;
        private TextBox textBoxPassword;
        private Button buttonLogin;
        private Label label1;
        private Label label2;
        private CheckBox ShowPasswordChekBox;
    }
}