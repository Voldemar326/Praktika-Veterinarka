﻿using System;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class DirectoryForm : Form
    {
        private string userRole;

        public DirectoryForm(string role)
        {
            InitializeComponent();
            userRole = role;
        }

        private void OwnersButton_Click(object sender, EventArgs e)
        {
            OwnersForm own = new OwnersForm(userRole);
            own.ShowDialog();
        }

        private void DiseasesButton_Click(object sender, EventArgs e)
        {
            DiseasesForm dis = new DiseasesForm(userRole);
            dis.ShowDialog();
        }

        private void VetsButton_Click(object sender, EventArgs e)
        {
            VetsForm vet = new VetsForm(userRole);
            vet.ShowDialog();
        }

        private void AnimalsButton_Click(object sender, EventArgs e)
        {
            AnimalsForm ani = new AnimalsForm(userRole);
            ani.ShowDialog();
        }
    }
}
