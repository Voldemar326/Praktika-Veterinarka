﻿using Npgsql;
using System;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class AutorizationForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;";

        public AutorizationForm()
        {
            InitializeComponent();
            textBoxPassword.UseSystemPasswordChar = true;
            ShowPasswordChekBox.CheckedChanged += ShowPasswordChekBox_CheckedChanged;
        }

        private void buttonLogin_Click_1(object sender, EventArgs e)
        {
            string login = textBoxLogin.Text.Trim();
            string password = textBoxPassword.Text.Trim();

            if (login == "" || password == "")
            {
                MessageBox.Show("Введите логин и пароль");
                return;
            }

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "SELECT role FROM users WHERE username=@u AND password_hash=@p";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("u", login);
                        cmd.Parameters.AddWithValue("p", password);

                        var roleObj = cmd.ExecuteScalar();

                        if (roleObj == null)
                        {
                            MessageBox.Show("Неверный логин или пароль");
                            return;
                        }

                        // roleObj — BOOLEAN из PostgreSQL
                        bool isAdmin = (bool)roleObj;

                        // Преобразуем в строку для Form1
                        string userRole = isAdmin ? "admin" : "vet";

                        MessageBox.Show($"Добро пожаловать, {login}! Роль: {userRole}");

                        // Открываем Form1 и передаём роль
                        Form1 main = new Form1(userRole);
                        main.Show();
                        this.Hide();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения: " + ex.Message);
            }
        }

        private void ShowPasswordChekBox_CheckedChanged(object sender, EventArgs e)
        {
            textBoxPassword.UseSystemPasswordChar = !ShowPasswordChekBox.Checked;
        }
    }
}
