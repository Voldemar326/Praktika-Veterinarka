﻿namespace vet_clinic_2
{
    partial class AdminEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminEditForm));
            DeleteUser = new Button();
            EditUser = new Button();
            AddUser = new Button();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // DeleteUser
            // 
            DeleteUser.Location = new Point(245, 239);
            DeleteUser.Name = "DeleteUser";
            DeleteUser.Size = new Size(118, 53);
            DeleteUser.TabIndex = 11;
            DeleteUser.Text = "Удалить пользователя";
            DeleteUser.UseVisualStyleBackColor = true;
            DeleteUser.Click += DeleteUser_Click;
            // 
            // EditUser
            // 
            EditUser.Location = new Point(110, 239);
            EditUser.Name = "EditUser";
            EditUser.Size = new Size(129, 53);
            EditUser.TabIndex = 10;
            EditUser.Text = "Редактировать пользователя";
            EditUser.UseVisualStyleBackColor = true;
            EditUser.Click += EditUser_Click;
            // 
            // AddUser
            // 
            AddUser.Location = new Point(12, 239);
            AddUser.Name = "AddUser";
            AddUser.Size = new Size(92, 53);
            AddUser.TabIndex = 9;
            AddUser.Text = "Добавить пользователя";
            AddUser.UseVisualStyleBackColor = true;
            AddUser.Click += AddUser_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(351, 221);
            dataGridView1.TabIndex = 8;
            // 
            // AdminEditForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(376, 304);
            Controls.Add(DeleteUser);
            Controls.Add(EditUser);
            Controls.Add(AddUser);
            Controls.Add(dataGridView1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AdminEditForm";
            Text = "Просмотр пользователей";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button DeleteUser;
        private Button EditUser;
        private Button AddUser;
        private DataGridView dataGridView1;
    }
}