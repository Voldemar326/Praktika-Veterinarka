﻿namespace vet_clinic_2
{
    partial class VetsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VetsForm));
            DeleteVets = new Button();
            EditVets = new Button();
            AddVets = new Button();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // DeleteVets
            // 
            DeleteVets.Location = new Point(353, 271);
            DeleteVets.Name = "DeleteVets";
            DeleteVets.Size = new Size(120, 53);
            DeleteVets.TabIndex = 11;
            DeleteVets.Text = "Удалить владельца";
            DeleteVets.UseVisualStyleBackColor = true;
            DeleteVets.Click += DeleteVets_Click;
            // 
            // EditVets
            // 
            EditVets.Location = new Point(168, 271);
            EditVets.Name = "EditVets";
            EditVets.Size = new Size(149, 53);
            EditVets.TabIndex = 10;
            EditVets.Text = "Редактировать владельца";
            EditVets.UseVisualStyleBackColor = true;
            EditVets.Click += EditVets_Click;
            // 
            // AddVets
            // 
            AddVets.Location = new Point(12, 271);
            AddVets.Name = "AddVets";
            AddVets.Size = new Size(116, 53);
            AddVets.TabIndex = 9;
            AddVets.Text = "Добавить владельца";
            AddVets.UseVisualStyleBackColor = true;
            AddVets.Click += AddVets_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(461, 253);
            dataGridView1.TabIndex = 8;
            // 
            // VetsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(482, 336);
            Controls.Add(DeleteVets);
            Controls.Add(EditVets);
            Controls.Add(AddVets);
            Controls.Add(dataGridView1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "VetsForm";
            Text = "VetsForm";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button DeleteVets;
        private Button EditVets;
        private Button AddVets;
        private DataGridView dataGridView1;
    }
}