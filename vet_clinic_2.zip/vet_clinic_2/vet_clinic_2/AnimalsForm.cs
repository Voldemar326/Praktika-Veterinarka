﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace vet_clinic_2
{
    public partial class AnimalsForm : Form
    {
        private string connectionString =
            "Host=localhost;Port=5432;Database=Vet_Clinic;Username=postgres;Password=Mencelai326;Encoding=UTF8;";

        private string userRole;

        // ✔ Правильный конструктор — принимает роль
        public AnimalsForm(string role)
        {
            InitializeComponent();
            userRole = role;

            ApplyPermissions();   // применяем ограничения
            LoadAnimals();        // загружаем данные
        }

        private void LoadAnimals()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            a.animal_id AS ""ID"",
                            a.name AS ""Кличка"",
                            a.species AS ""Вид"",
                            a.breed AS ""Порода"",
                            a.sex AS ""Пол"",
                            a.birth_date AS ""Дата рождения"",
                            o.full_name AS ""Владелец"",
                            a.notes AS ""Заметки""
                        FROM animals a
                        LEFT JOIN owners o ON a.owner_id = o.owner_id
                        ORDER BY a.animal_id;
                    ";

                    using (var adapter = new NpgsqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void AddAnimal_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для добавления записей.");
                return;
            }

            AddAnimalForm form = new AddAnimalForm();
            if (form.ShowDialog() == DialogResult.OK)
                LoadAnimals();
        }

        private void EditAnimal_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для редактирования записей.");
                return;
            }

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите животное для редактирования");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

            AddAnimalForm form = new AddAnimalForm(id);
            if (form.ShowDialog() == DialogResult.OK)
                LoadAnimals();
        }

        private void DeleteAnimal_Click(object sender, EventArgs e)
        {
            if (userRole == "vet")
            {
                MessageBox.Show("У вас нет прав для удаления записей.");
                return;
            }

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите животное для удаления");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

            DialogResult result = MessageBox.Show(
                "Вы действительно хотите удалить выбранное животное?",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "DELETE FROM animals WHERE animal_id=@id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Животное успешно удалено");
                LoadAnimals();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message);
            }
        }

        // ✔ Ограничения по роли
        private void ApplyPermissions()
        {
            if (userRole == "vet")
            {
                if (AddAnimal != null)
                    AddAnimal.Enabled = false;

                if (EditAnimal != null)
                    EditAnimal.Enabled = false;

                if (DeleteAnimal != null)
                    DeleteAnimal.Enabled = false;
            }
        }
    }
}
