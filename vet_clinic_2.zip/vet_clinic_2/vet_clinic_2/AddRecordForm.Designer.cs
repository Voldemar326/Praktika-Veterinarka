﻿namespace vet_clinic_2
{
    partial class AddRecordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddRecordForm));
            comboBoxAnimal = new ComboBox();
            comboBoxVet = new ComboBox();
            dateTimePickerDate = new DateTimePicker();
            comboBoxDiagnosis = new ComboBox();
            textBoxDescription = new TextBox();
            textBoxCost = new TextBox();
            SaveButton = new Button();
            CanselButton = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            comboBoxType = new ComboBox();
            SuspendLayout();
            // 
            // comboBoxAnimal
            // 
            comboBoxAnimal.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxAnimal.FormattingEnabled = true;
            comboBoxAnimal.Location = new Point(73, 6);
            comboBoxAnimal.Name = "comboBoxAnimal";
            comboBoxAnimal.Size = new Size(134, 23);
            comboBoxAnimal.TabIndex = 0;
            // 
            // comboBoxVet
            // 
            comboBoxVet.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxVet.FormattingEnabled = true;
            comboBoxVet.Location = new Point(73, 35);
            comboBoxVet.Name = "comboBoxVet";
            comboBoxVet.Size = new Size(134, 23);
            comboBoxVet.TabIndex = 1;
            // 
            // dateTimePickerDate
            // 
            dateTimePickerDate.Location = new Point(73, 65);
            dateTimePickerDate.Name = "dateTimePickerDate";
            dateTimePickerDate.Size = new Size(134, 23);
            dateTimePickerDate.TabIndex = 2;
            // 
            // comboBoxDiagnosis
            // 
            comboBoxDiagnosis.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxDiagnosis.FormattingEnabled = true;
            comboBoxDiagnosis.Location = new Point(73, 123);
            comboBoxDiagnosis.Name = "comboBoxDiagnosis";
            comboBoxDiagnosis.Size = new Size(134, 23);
            comboBoxDiagnosis.TabIndex = 4;
            // 
            // textBoxDescription
            // 
            textBoxDescription.Location = new Point(12, 199);
            textBoxDescription.MaxLength = 270;
            textBoxDescription.Multiline = true;
            textBoxDescription.Name = "textBoxDescription";
            textBoxDescription.Size = new Size(195, 100);
            textBoxDescription.TabIndex = 5;
            // 
            // textBoxCost
            // 
            textBoxCost.Location = new Point(87, 152);
            textBoxCost.Name = "textBoxCost";
            textBoxCost.Size = new Size(120, 23);
            textBoxCost.TabIndex = 6;
            // 
            // SaveButton
            // 
            SaveButton.Location = new Point(0, 305);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(75, 23);
            SaveButton.TabIndex = 7;
            SaveButton.Text = "Сохранить";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // CanselButton
            // 
            CanselButton.Location = new Point(136, 305);
            CanselButton.Name = "CanselButton";
            CanselButton.Size = new Size(75, 23);
            CanselButton.TabIndex = 8;
            CanselButton.Text = "Отмена";
            CanselButton.UseVisualStyleBackColor = true;
            CanselButton.Click += CanselButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(7, 9);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 9;
            label1.Text = "Питомец:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(7, 40);
            label2.Name = "label2";
            label2.Size = new Size(68, 15);
            label2.TabIndex = 10;
            label2.Text = "Ветеринар:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(-1, 71);
            label3.Name = "label3";
            label3.Size = new Size(76, 15);
            label3.TabIndex = 11;
            label3.Text = "Дата записи:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(-1, 94);
            label4.Name = "label4";
            label4.Size = new Size(71, 15);
            label4.TabIndex = 12;
            label4.Text = "Тип записи:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 126);
            label5.Name = "label5";
            label5.Size = new Size(55, 15);
            label5.TabIndex = 13;
            label5.Text = "Диагноз:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(5, 181);
            label6.Name = "label6";
            label6.Size = new Size(65, 15);
            label6.TabIndex = 14;
            label6.Text = "Описание:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(5, 155);
            label7.Name = "label7";
            label7.Size = new Size(70, 15);
            label7.TabIndex = 15;
            label7.Text = "Стоимость:";
            // 
            // comboBoxType
            // 
            comboBoxType.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxType.FormattingEnabled = true;
            comboBoxType.Location = new Point(73, 94);
            comboBoxType.Name = "comboBoxType";
            comboBoxType.Size = new Size(134, 23);
            comboBoxType.TabIndex = 16;
            // 
            // AddRecordForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(223, 340);
            Controls.Add(comboBoxType);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(CanselButton);
            Controls.Add(SaveButton);
            Controls.Add(textBoxCost);
            Controls.Add(textBoxDescription);
            Controls.Add(comboBoxDiagnosis);
            Controls.Add(dateTimePickerDate);
            Controls.Add(comboBoxVet);
            Controls.Add(comboBoxAnimal);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddRecordForm";
            Text = "Работа с записями";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBoxAnimal;
        private ComboBox comboBoxVet;
        private DateTimePicker dateTimePickerDate;
        private ComboBox comboBoxDiagnosis;
        private TextBox textBoxDescription;
        private TextBox textBoxCost;
        private Button SaveButton;
        private Button CanselButton;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private ComboBox comboBoxType;
    }
}