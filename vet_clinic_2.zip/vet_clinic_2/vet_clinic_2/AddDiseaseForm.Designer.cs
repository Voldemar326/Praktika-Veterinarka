﻿namespace vet_clinic_2
{
    partial class AddDiseaseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddDiseaseForm));
            NameTextBox = new TextBox();
            DescriptionTextBox = new TextBox();
            SimptomsTextBox = new TextBox();
            HealingTextBox = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            SaveButton = new Button();
            CanselButton = new Button();
            SuspendLayout();
            // 
            // NameTextBox
            // 
            NameTextBox.Location = new Point(129, 6);
            NameTextBox.MaxLength = 40;
            NameTextBox.Name = "NameTextBox";
            NameTextBox.Size = new Size(331, 23);
            NameTextBox.TabIndex = 0;
            // 
            // DescriptionTextBox
            // 
            DescriptionTextBox.Location = new Point(129, 36);
            DescriptionTextBox.MaxLength = 270;
            DescriptionTextBox.Multiline = true;
            DescriptionTextBox.Name = "DescriptionTextBox";
            DescriptionTextBox.Size = new Size(331, 121);
            DescriptionTextBox.TabIndex = 1;
            // 
            // SimptomsTextBox
            // 
            SimptomsTextBox.Location = new Point(129, 168);
            SimptomsTextBox.MaxLength = 270;
            SimptomsTextBox.Multiline = true;
            SimptomsTextBox.Name = "SimptomsTextBox";
            SimptomsTextBox.Size = new Size(331, 105);
            SimptomsTextBox.TabIndex = 2;
            // 
            // HealingTextBox
            // 
            HealingTextBox.Location = new Point(129, 279);
            HealingTextBox.MaxLength = 270;
            HealingTextBox.Multiline = true;
            HealingTextBox.Name = "HealingTextBox";
            HealingTextBox.Size = new Size(331, 73);
            HealingTextBox.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(111, 15);
            label1.TabIndex = 4;
            label1.Text = "Название болезни:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 36);
            label2.Name = "label2";
            label2.Size = new Size(114, 15);
            label2.TabIndex = 5;
            label2.Text = "Описание болезни:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(52, 168);
            label3.Name = "label3";
            label3.Size = new Size(71, 15);
            label3.TabIndex = 6;
            label3.Text = "Симптомы:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(66, 282);
            label4.Name = "label4";
            label4.Size = new Size(57, 15);
            label4.TabIndex = 7;
            label4.Text = "Лечение:";
            // 
            // SaveButton
            // 
            SaveButton.Location = new Point(12, 372);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(111, 40);
            SaveButton.TabIndex = 8;
            SaveButton.Text = "Сохранить";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // CanselButton
            // 
            CanselButton.Location = new Point(357, 372);
            CanselButton.Name = "CanselButton";
            CanselButton.Size = new Size(103, 40);
            CanselButton.TabIndex = 9;
            CanselButton.Text = "Отмена";
            CanselButton.UseVisualStyleBackColor = true;
            CanselButton.Click += CanselButton_Click;
            // 
            // AddDiseaseForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(477, 424);
            Controls.Add(CanselButton);
            Controls.Add(SaveButton);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(HealingTextBox);
            Controls.Add(SimptomsTextBox);
            Controls.Add(DescriptionTextBox);
            Controls.Add(NameTextBox);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddDiseaseForm";
            Text = "Работа с диагнозами";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox NameTextBox;
        private TextBox DescriptionTextBox;
        private TextBox SimptomsTextBox;
        private TextBox HealingTextBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button SaveButton;
        private Button CanselButton;
    }
}