﻿namespace vet_clinic_2
{
    partial class DirectoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DirectoryForm));
            groupBox1 = new GroupBox();
            AnimalsButton = new Button();
            OwnersButton = new Button();
            DiseasesButton = new Button();
            VetsButton = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(AnimalsButton);
            groupBox1.Controls.Add(OwnersButton);
            groupBox1.Controls.Add(DiseasesButton);
            groupBox1.Controls.Add(VetsButton);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(162, 223);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Выбор категории";
            // 
            // AnimalsButton
            // 
            AnimalsButton.Location = new Point(6, 169);
            AnimalsButton.Name = "AnimalsButton";
            AnimalsButton.Size = new Size(147, 43);
            AnimalsButton.TabIndex = 3;
            AnimalsButton.Text = "Питомцы";
            AnimalsButton.UseVisualStyleBackColor = true;
            AnimalsButton.Click += AnimalsButton_Click;
            // 
            // OwnersButton
            // 
            OwnersButton.Location = new Point(6, 22);
            OwnersButton.Name = "OwnersButton";
            OwnersButton.Size = new Size(147, 43);
            OwnersButton.TabIndex = 0;
            OwnersButton.Text = "Владельцы";
            OwnersButton.UseVisualStyleBackColor = true;
            OwnersButton.Click += OwnersButton_Click;
            // 
            // DiseasesButton
            // 
            DiseasesButton.Location = new Point(6, 71);
            DiseasesButton.Name = "DiseasesButton";
            DiseasesButton.Size = new Size(147, 43);
            DiseasesButton.TabIndex = 1;
            DiseasesButton.Text = "Диагнозы";
            DiseasesButton.UseVisualStyleBackColor = true;
            DiseasesButton.Click += DiseasesButton_Click;
            // 
            // VetsButton
            // 
            VetsButton.Location = new Point(6, 120);
            VetsButton.Name = "VetsButton";
            VetsButton.Size = new Size(147, 43);
            VetsButton.TabIndex = 2;
            VetsButton.Text = "Ветеринары";
            VetsButton.UseVisualStyleBackColor = true;
            VetsButton.Click += VetsButton_Click;
            // 
            // DirectoryForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(177, 243);
            Controls.Add(groupBox1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "DirectoryForm";
            Text = "Справочник";
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button AnimalsButton;
        private Button OwnersButton;
        private Button DiseasesButton;
        private Button VetsButton;
    }
}